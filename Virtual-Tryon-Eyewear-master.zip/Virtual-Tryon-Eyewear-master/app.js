window.EventListener = require('./scripts/EventListener.js').default;
window.Tryon = require('./scripts/Tryon.js').default;